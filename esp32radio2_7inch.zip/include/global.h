#pragma once
#include <Arduino.h>

// Band Types
#define FM_BAND_TYPE 0
#define MW_BAND_TYPE 1
#define SW_BAND_TYPE 2
#define LW_BAND_TYPE 3

// Modes
#define FM  0
#define LSB 1
#define USB 2
#define AM  3


#define GFX_DISPLAY_EXTCOMIN  8

// Rotary encoder
#define ROTARY_ENCODER_A_PIN 2
#define ROTARY_ENCODER_B_PIN 1
#define ROTARY_ENCODER_BUTTON_PIN 21
#define ROTARY_ENCODER_VCC_PIN 15


// I2C bus pins
#define ESP32_I2C_SDA 18
#define ESP32_I2C_SCL 17

#define RESET_PIN 16

#define AUDIO_MUTE 3
#define AMP_EN 10
#define AUDIO_INPUT 5

void hal_extcom_start();

const char* getStrValue(const char* str, uint8_t index);
